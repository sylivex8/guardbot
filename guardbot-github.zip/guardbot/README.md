# 🛡️ GuardBot — Dyno-Style Public Discord Moderation Bot

A fully-featured, public Discord moderation bot with a Dyno-style web dashboard. Moderation, AutoMod, leveling, tickets, starboard, reaction roles, anti-raid, and more.

---

## 📦 Features

### 🤖 Bot Commands (24 Slash Commands)

**Moderation**
- `/ban` — Ban with message deletion options
- `/unban` — Unban by user ID
- `/kick` — Kick a member
- `/mute` — Discord timeout (up to 28 days)
- `/unmute` — Remove timeout early
- `/warn` — Issue warnings with auto-punishment thresholds
- `/warnings` — View user warnings
- `/delwarn` — Remove specific warning by ID
- `/clearwarnings` — Clear all warnings
- `/purge` — Bulk delete with filters (bots, humans, links, images)
- `/slowmode` — Set/disable channel slowmode
- `/lockdown` — Lock/unlock channels
- `/nick` — Change/reset nicknames
- `/role` — Add/remove roles
- `/modlogs` — View mod history

**Utility**
- `/userinfo` — Detailed user info with XP/warnings
- `/serverinfo` — Server stats
- `/avatar` — High-res avatar

**Fun**
- `/rank` — View XP rank
- `/leaderboard` — Top 10 XP leaderboard
- `/poll` — Multi-option polls
- `/8ball` — Magic 8-ball

**Tickets**
- `/ticket` — Open support ticket
- `/closeticket` — Close ticket

### 🛡️ AutoMod Rules
- Banned words/phrases
- Mass mention blocking
- Emoji spam filter
- Anti-spam (rate limiting)
- Link filter with whitelist
- Discord invite blocker
- Caps filter (configurable %)
- Duplicate message filter
- New account age filter
- Auto-punishments (warn → mute → kick → ban)

### 🌟 Features
- XP Leveling system with configurable rates
- Starboard with custom emoji and threshold
- Reaction Roles
- Support Ticket system with categories
- Welcome/Leave messages with variables
- Member Verification (react to verify)
- Anti-Raid protection (join rate detection)
- Persistent mod logs (1000 per guild)
- Per-server configuration

### 🌐 Web Dashboard (Dyno-style)
- **Landing page** — Marketing site with live bot stats
- **Server selector** — Shows all servers you manage
- **Per-server dashboard** with 13 configuration pages:
  - Overview (stats, recent actions, server info)
  - Mod Logs (filterable history)
  - AutoMod configuration
  - Warnings lookup
  - Join/Leave messages
  - Leveling + leaderboard
  - Starboard
  - Reaction Roles
  - Tickets + open ticket management
  - Verification
  - Anti-Raid
  - Settings (roles, log channel, prefix)
  - Commands browser

---

## 🚀 Setup

### 1. Create Discord Application
1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Create app → Bot tab → **Reset Token** → copy token
3. Enable **Server Members Intent**, **Message Content Intent**, **Presence Intent**
4. OAuth2 → General → add redirect: `http://localhost:3001/auth/callback`
5. Invite URL: `https://discord.com/api/oauth2/authorize?client_id=YOUR_ID&permissions=8&scope=bot%20applications.commands`

### 2. Configure Environment
```bash
cd bot
cp .env.example .env
```

Edit `.env`:
```
DISCORD_TOKEN=your_bot_token
CLIENT_ID=your_application_id
CLIENT_SECRET=your_oauth2_secret   # From OAuth2 → General
REDIRECT_URI=http://localhost:3001/auth/callback
SESSION_SECRET=some_random_string
API_PORT=3001
```

### 3. Install & Run
```bash
cd bot
npm install
npm start
```

### 4. Open Dashboard
Open `website/index.html` or `website/dashboard.html` in your browser.
Click **Log in with Discord** to authenticate.

### 5. Replace YOUR_CLIENT_ID
Search for `YOUR_CLIENT_ID` in both HTML files and replace with your Application ID.

---

## 📁 Project Structure
```
guardbot/
├── bot/
│   ├── index.js              # Main entry point
│   ├── package.json
│   ├── .env.example
│   ├── commands/
│   │   └── commands.js       # All 24 commands
│   ├── events/
│   │   ├── ready.js
│   │   ├── interactionCreate.js
│   │   ├── messageCreate.js  # AutoMod + leveling
│   │   ├── guildMemberAdd.js # Welcome + anti-raid
│   │   ├── guildMemberRemove.js
│   │   ├── messageReactionAdd.js  # Reaction roles + starboard
│   │   └── messageReactionRemove.js
│   ├── modules/
│   │   ├── database.js       # JSON-based persistence
│   │   ├── api.js            # Express REST API + OAuth2
│   │   └── logger.js         # Mod action logger
│   └── data/                 # Auto-created, stores all data
├── website/
│   ├── index.html            # Public landing page
│   └── dashboard.html        # Full Dyno-style dashboard
└── README.md
```

---

## 🔧 Production Tips

1. **Database**: Replace `modules/database.js` with SQLite (`better-sqlite3`) or MongoDB for production
2. **Hosting**: Deploy bot on Railway, Heroku, or VPS; serve dashboard via Nginx/Vercel
3. **HTTPS**: Required for OAuth2 in production — use Let's Encrypt
4. **REDIRECT_URI**: Update to your production URL
5. **SESSION_SECRET**: Use a cryptographically random 32+ character string

---

## 🌐 API Reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/status` | Bot status, ping, guild count |
| GET | `/api/public/stats` | Public stats (no auth) |
| GET | `/api/commands` | All slash commands |
| GET | `/api/guilds` | User's mutual servers |
| GET | `/api/guild/:id/info` | Guild config + stats |
| POST | `/api/guild/:id/config` | Update guild config |
| GET | `/api/guild/:id/logs` | Mod logs |
| GET | `/api/guild/:id/warnings/:userId` | User warnings |
| DELETE | `/api/guild/:id/warnings/:userId` | Clear warnings |
| GET | `/api/guild/:id/leaderboard` | XP leaderboard |
| GET | `/api/guild/:id/tickets` | Open tickets |
| GET | `/auth/discord` | Start OAuth2 flow |
| GET | `/auth/callback` | OAuth2 callback |
| GET | `/auth/me` | Current user session |
