const { EmbedBuilder } = require('discord.js');

// guildMemberRemove
const leaveEvent = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    const cfg = client.db.getGuildConfig(member.guild.id);
    if (cfg.joinLeave?.enabled && cfg.joinLeave.channelId && cfg.joinLeave.leaveMsg) {
      const channel = member.guild.channels.cache.get(cfg.joinLeave.channelId);
      if (channel) {
        const msg = cfg.joinLeave.leaveMsg
          .replace('{user}', `<@${member.id}>`)
          .replace('{username}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount);

        const embed = new EmbedBuilder().setColor(0xed4245)
          .setDescription(msg)
          .setThumbnail(member.user.displayAvatarURL())
          .setTimestamp();

        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }
  },
};

module.exports = leaveEvent;
