const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    // Slash commands
    if (interaction.isChatInputCommand()) {
      const cmd = client.commands.get(interaction.commandName);
      if (!cmd) return;

      // Cooldowns
      const { cooldowns } = client;
      if (!cooldowns.has(cmd.data.name)) cooldowns.set(cmd.data.name, new Map());
      const now = Date.now();
      const timestamps = cooldowns.get(cmd.data.name);
      const cooldownAmount = (cmd.cooldown || 3) * 1000;
      if (timestamps.has(interaction.user.id)) {
        const expiry = timestamps.get(interaction.user.id) + cooldownAmount;
        if (now < expiry) {
          const timeLeft = ((expiry - now) / 1000).toFixed(1);
          return interaction.reply({
            embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`⏱️ Cooldown: wait **${timeLeft}s** before using \`/${cmd.data.name}\` again.`)],
            ephemeral: true,
          });
        }
      }
      timestamps.set(interaction.user.id, now);
      setTimeout(() => timestamps.delete(interaction.user.id), cooldownAmount);

      try {
        await cmd.execute(interaction, client);
      } catch (err) {
        console.error(`[CMD ERROR] ${interaction.commandName}:`, err);
        const msg = { embeds: [new EmbedBuilder().setColor(0xed4245).setDescription(`❌ An error occurred: ${err.message}`)], ephemeral: true };
        if (interaction.replied || interaction.deferred) interaction.followUp(msg);
        else interaction.reply(msg);
      }
    }

    // Reaction role buttons / select menus (if added later)
    if (interaction.isButton()) {
      // Ticket close button
      if (interaction.customId === 'close_ticket') {
        const ticket = client.db.getTicket(interaction.guild.id, interaction.channel.id);
        if (ticket) {
          await interaction.reply({ content: '🔒 Closing ticket in 5 seconds...' });
          client.db.closeTicket(interaction.guild.id, interaction.channel.id);
          setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
        }
      }
    }
  },
};
