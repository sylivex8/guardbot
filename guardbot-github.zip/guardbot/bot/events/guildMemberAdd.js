const { EmbedBuilder } = require('discord.js');

const joinTimestamps = []; // for anti-raid tracking

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const cfg = client.db.getGuildConfig(member.guild.id);

    // ── Anti-Raid ─────────────────────────────────────────────────────────────
    if (cfg.antiRaid?.enabled) {
      const now = Date.now();
      joinTimestamps.push(now);
      const recent = joinTimestamps.filter(t => now - t < (cfg.antiRaid.joinWindow || 10000));
      if (recent.length >= (cfg.antiRaid.joinThreshold || 10)) {
        const action = cfg.antiRaid.action || 'kick';
        if (action === 'ban') {
          await member.ban({ reason: 'Anti-Raid: Unusual join spike' }).catch(() => {});
        } else if (action === 'kick') {
          await member.kick('Anti-Raid: Unusual join spike').catch(() => {});
        }
        // Log it
        client.db.addLog(member.guild.id, {
          action: 'automod',
          moderator: { id: client.user.id, tag: 'GuardBot AutoMod' },
          target: { id: member.user.id, tag: member.user.tag },
          reason: `Anti-Raid triggered (${recent.length} joins in ${cfg.antiRaid.joinWindow/1000}s)`,
        });
        return;
      }
    }

    // ── Join Message ──────────────────────────────────────────────────────────
    if (cfg.joinLeave?.enabled && cfg.joinLeave.channelId && cfg.joinLeave.joinMsg) {
      const channel = member.guild.channels.cache.get(cfg.joinLeave.channelId);
      if (channel) {
        const msg = cfg.joinLeave.joinMsg
          .replace('{user}', `<@${member.id}>`)
          .replace('{username}', member.user.username)
          .replace('{server}', member.guild.name)
          .replace('{count}', member.guild.memberCount);

        const embed = new EmbedBuilder().setColor(0x57f287)
          .setDescription(msg)
          .setThumbnail(member.user.displayAvatarURL())
          .setFooter({ text: `Member #${member.guild.memberCount}` })
          .setTimestamp();

        channel.send({ embeds: [embed] }).catch(() => {});
      }
    }

    // ── Verification ──────────────────────────────────────────────────────────
    if (cfg.verification?.enabled && cfg.verification.channelId) {
      const channel = member.guild.channels.cache.get(cfg.verification.channelId);
      if (channel) {
        const embed = new EmbedBuilder().setColor(0x5865f2)
          .setTitle('✅ Verify to access the server')
          .setDescription(cfg.verification.message || 'React with ✅ to verify.')
          .setFooter({ text: `Welcome, ${member.user.username}!` });
        const msg = await channel.send({ content: `<@${member.id}>`, embeds: [embed] });
        await msg.react('✅');
      }
    }
  },
};
