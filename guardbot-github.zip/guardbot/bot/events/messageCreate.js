const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { logAction } = require('../modules/logger');

const _dupeMap = new Map(); // userId -> last message

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const cfg = client.db.getGuildConfig(message.guild.id);

    // ── Leveling ──────────────────────────────────────────────────────────────
    if (cfg.leveling?.enabled) {
      const canGain = client.db.checkXPCooldown(message.guild.id, message.author.id, cfg.leveling.xpCooldown || 60);
      if (canGain) {
        const gain = Math.floor(Math.random() * 10 + 5) * (cfg.leveling.xpRate || 1);
        const result = client.db.addXP(message.guild.id, message.author.id, gain);
        if (result.leveled && cfg.leveling.announceLevelUp) {
          const ch = cfg.leveling.announceChannelId ? message.guild.channels.cache.get(cfg.leveling.announceChannelId) : message.channel;
          if (ch) {
            ch.send({ embeds: [new EmbedBuilder().setColor(0x57f287)
              .setDescription(`🎉 <@${message.author.id}> leveled up to **Level ${result.level}**! ✨`)] }).catch(() => {});
          }
        }
      }
    }

    // ── AutoMod ───────────────────────────────────────────────────────────────
    if (!cfg.automod?.enabled) return;
    const am = cfg.automod;

    // Ignore certain channels/roles
    if (cfg.ignoredChannels?.includes(message.channel.id)) return;
    const memberRoleIds = message.member?.roles.cache.map(r => r.id) || [];
    if (cfg.ignoredRoles?.some(r => memberRoleIds.includes(r))) return;
    // Don't automod admins
    if (message.member?.permissions.has(PermissionFlagsBits.Administrator)) return;

    let violation = null;

    // Banned words
    if (!violation && am.bannedWords?.length) {
      const lower = message.content.toLowerCase();
      const hit = am.bannedWords.find(w => lower.includes(w.toLowerCase()));
      if (hit) violation = `Banned word`;
    }

    // Mass mentions
    if (!violation && message.mentions.users.size >= (am.maxMentions || 5)) {
      violation = `Mass mention (${message.mentions.users.size})`;
    }

    // Emoji spam
    if (!violation) {
      const emojiCount = (message.content.match(/\p{Emoji}/gu) || []).length;
      if (emojiCount >= (am.maxEmojis || 15)) violation = `Emoji spam (${emojiCount})`;
    }

    // Caps filter
    if (!violation && am.capsFilter?.enabled && message.content.length > 10) {
      const upper = (message.content.match(/[A-Z]/g) || []).length;
      const total = (message.content.match(/[a-zA-Z]/g) || []).length;
      if (total > 5 && (upper / total) * 100 >= (am.capsFilter.percent || 70)) {
        violation = `Excessive caps`;
      }
    }

    // Discord invite filter
    if (!violation && am.inviteFilter && /discord\.gg\/\S+/i.test(message.content)) {
      violation = `Discord invite link`;
    }

    // Link filter
    if (!violation && am.linkFilter?.enabled) {
      const linkMatch = message.content.match(/https?:\/\/\S+/gi);
      if (linkMatch) {
        const whitelist = am.linkFilter.whitelist || [];
        const blocked = linkMatch.some(link => !whitelist.some(w => link.includes(w)));
        if (blocked) violation = `Unauthorized link`;
      }
    }

    // Duplicate message filter
    if (!violation && am.duplicateFilter) {
      const last = _dupeMap.get(message.author.id);
      if (last === message.content && message.content.length > 5) violation = `Duplicate message`;
      _dupeMap.set(message.author.id, message.content);
    }

    // Anti-spam
    if (!violation && am.antiSpam?.enabled) {
      const isSpam = client.db.checkSpam(message.author.id, am.antiSpam.threshold || 5, am.antiSpam.window || 4000);
      if (isSpam) violation = `Message spam`;
    }

    // New account filter
    if (!violation && am.newAccountFilter?.enabled) {
      const ageMs = Date.now() - message.author.createdTimestamp;
      const ageDays = ageMs / 86400000;
      if (ageDays < (am.newAccountFilter.ageDays || 7)) violation = `New account (${Math.floor(ageDays)} days old)`;
    }

    if (violation) {
      await message.delete().catch(() => {});
      const warn = await message.channel.send({
        embeds: [new EmbedBuilder().setColor(0x5865f2)
          .setDescription(`🛡️ <@${message.author.id}> — **AutoMod:** ${violation}`)],
      });
      setTimeout(() => warn.delete().catch(() => {}), 6000);

      // Add automod warning
      const count = client.db.addWarning(message.guild.id, message.author.id, `[AutoMod] ${violation}`, client.user.id, 'AutoMod');
      await logAction(client, message.guild.id, 'automod', {
        target: message.author,
        reason: violation,
        extra: { Channel: `#${message.channel.name}`, Warnings: count },
      });

      // Auto-punish
      if (am.punishments) {
        const member = message.member;
        const p = am.punishments;
        if (p.ban && count >= p.ban) {
          await member.ban({ reason: `AutoMod: ${violation}` }).catch(() => {});
        } else if (p.kick && count >= p.kick) {
          await member.kick(`AutoMod: ${violation}`).catch(() => {});
        } else if (p.mute && count >= p.mute) {
          await member.timeout(600000, `AutoMod: ${violation}`).catch(() => {});
        }
      }
    }
  },
};
