module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    console.log(`📡 Serving ${client.guilds.cache.size} guilds`);

    // Set presence
    const setPresence = () => {
      const presences = [
        { name: `/help | ${client.guilds.cache.size} servers`, type: 3 },
        { name: 'your server 👀', type: 3 },
        { name: `${client.guilds.cache.reduce((a, g) => a + g.memberCount, 0).toLocaleString()} users`, type: 3 },
      ];
      let i = 0;
      const update = () => {
        client.user.setPresence({ activities: [presences[i]], status: 'online' });
        i = (i + 1) % presences.length;
      };
      update();
      setInterval(update, 30000);
    };
    setPresence();

    // Ensure all guilds have configs initialized
    for (const [id] of client.guilds.cache) {
      client.db.getGuildConfig(id);
    }
  },
};
