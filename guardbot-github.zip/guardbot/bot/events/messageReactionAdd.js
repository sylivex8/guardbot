const { EmbedBuilder } = require('discord.js');

async function handleReaction(reaction, user, add, client) {
  if (user.bot) return;
  if (reaction.partial) { try { await reaction.fetch(); } catch { return; } }
  if (!reaction.message.guild) return;

  const guild = reaction.message.guild;
  const cfg = client.db.getGuildConfig(guild.id);
  const emoji = reaction.emoji.name;

  // ── Reaction Roles ─────────────────────────────────────────────────────────
  const rr = client.db.getReactionRole(guild.id, reaction.message.id, emoji);
  if (rr) {
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = guild.roles.cache.get(rr.roleId);
    if (!role) return;
    if (add) member.roles.add(role).catch(() => {});
    else member.roles.remove(role).catch(() => {});
  }

  // ── Verification ───────────────────────────────────────────────────────────
  if (add && emoji === '✅' && cfg.verification?.enabled && cfg.verification.roleId) {
    if (reaction.message.channel.id === cfg.verification.channelId) {
      const member = await guild.members.fetch(user.id).catch(() => null);
      if (member) {
        member.roles.add(cfg.verification.roleId).catch(() => {});
        reaction.message.delete().catch(() => {});
      }
    }
  }

  // ── Starboard ──────────────────────────────────────────────────────────────
  if (cfg.starboard?.enabled && emoji === (cfg.starboard.emoji || '⭐') && add) {
    const count = reaction.count;
    const threshold = cfg.starboard.threshold || 3;
    if (count < threshold) return;

    const sbChannel = guild.channels.cache.get(cfg.starboard.channelId);
    if (!sbChannel) return;

    const msg = reaction.message;
    const existing = client.db.getStarboardEntry(guild.id, msg.id);

    const embed = new EmbedBuilder().setColor(0xfee75c)
      .setAuthor({ name: msg.author.tag, iconURL: msg.author.displayAvatarURL() })
      .setDescription(msg.content || '(no text)')
      .addFields({ name: 'Source', value: `[Jump to message](${msg.url})` })
      .setTimestamp(msg.createdAt);

    if (msg.attachments.first()) embed.setImage(msg.attachments.first().url);

    const starContent = `⭐ **${count}** | <#${msg.channel.id}>`;

    if (existing) {
      const sbMsg = await sbChannel.messages.fetch(existing.starboardMessageId).catch(() => null);
      if (sbMsg) await sbMsg.edit({ content: starContent, embeds: [embed] }).catch(() => {});
    } else {
      const sent = await sbChannel.send({ content: starContent, embeds: [embed] }).catch(() => null);
      if (sent) client.db.setStarboardEntry(guild.id, msg.id, { starboardMessageId: sent.id });
    }
  }

  // ── Ticket close reaction ──────────────────────────────────────────────────
  if (add && emoji === '🔒') {
    const ticket = client.db.getTicket(guild.id, reaction.message.channel.id);
    if (ticket) {
      const member = await guild.members.fetch(user.id).catch(() => null);
      if (!member) return;
      const cfg2 = client.db.getGuildConfig(guild.id);
      const isMod = member.permissions.has(0x2) || (cfg2.modRoles || []).some(r => member.roles.cache.has(r));
      if (isMod || member.id === ticket.userId) {
        reaction.message.channel.send({ embeds: [new EmbedBuilder().setColor(0xfaa61a).setDescription('🔒 Ticket closing in 5 seconds...')] });
        client.db.closeTicket(guild.id, reaction.message.channel.id);
        setTimeout(() => reaction.message.channel.delete().catch(() => {}), 5000);
      }
    }
  }
}

module.exports = {
  name: 'messageReactionAdd',
  async execute(reaction, user, client) {
    await handleReaction(reaction, user, true, client);
  },
};
