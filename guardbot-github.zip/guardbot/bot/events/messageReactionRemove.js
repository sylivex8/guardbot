const { EmbedBuilder } = require('discord.js');

async function handleReactionRemove(reaction, user, client) {
  if (user.bot) return;
  if (reaction.partial) { try { await reaction.fetch(); } catch { return; } }
  if (!reaction.message.guild) return;

  const guild = reaction.message.guild;
  const emoji = reaction.emoji.name;

  // Reaction roles - remove role on unreact
  const rr = client.db.getReactionRole(guild.id, reaction.message.id, emoji);
  if (rr) {
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;
    const role = guild.roles.cache.get(rr.roleId);
    if (role) member.roles.remove(role).catch(() => {});
  }
}

module.exports = {
  name: 'messageReactionRemove',
  async execute(reaction, user, client) {
    await handleReactionRemove(reaction, user, client);
  },
};
