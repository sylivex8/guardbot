const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { logAction } = require('../modules/logger');

function modEmbed(color, desc) {
  return new EmbedBuilder().setColor(color).setDescription(desc).setTimestamp();
}

// ── /ban ──────────────────────────────────────────────────────────────────────
module.exports = [

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('ban').setDescription('Ban a member from the server')
    .addUserOption(o => o.setName('user').setDescription('User to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban'))
    .addIntegerOption(o => o.setName('days').setDescription('Delete messages from last N days (0-7)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const days = interaction.options.getInteger('days') || 0;
    const member = interaction.guild.members.cache.get(user.id);

    if (member) {
      if (!member.bannable) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ I cannot ban this user.')], ephemeral: true });
      if (member.roles.highest.position >= interaction.member.roles.highest.position)
        return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ You cannot ban someone with an equal or higher role.')], ephemeral: true });
    }

    try {
      await user.send({ embeds: [modEmbed(0xed4245, `🔨 You have been **banned** from **${interaction.guild.name}**\n**Reason:** ${reason}`)] }).catch(() => {});
      await interaction.guild.members.ban(user, { reason, deleteMessageSeconds: days * 86400 });
      await logAction(client, interaction.guild.id, 'ban', { moderator: interaction.user, target: user, reason });
      interaction.reply({ embeds: [modEmbed(0xed4245, `🔨 **${user.tag}** has been banned.\n**Reason:** ${reason}`)] });
    } catch (e) {
      interaction.reply({ embeds: [modEmbed(0xed4245, `❌ ${e.message}`)], ephemeral: true });
    }
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('unban').setDescription('Unban a user by their ID')
    .addStringOption(o => o.setName('userid').setDescription('User ID to unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
  async execute(interaction, client) {
    const userId = interaction.options.getString('userid');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    try {
      const user = await client.users.fetch(userId);
      await interaction.guild.members.unban(userId, reason);
      await logAction(client, interaction.guild.id, 'unban', { moderator: interaction.user, target: user, reason });
      interaction.reply({ embeds: [modEmbed(0x57f287, `✅ **${user.tag}** has been unbanned.`)] });
    } catch (e) {
      interaction.reply({ embeds: [modEmbed(0xed4245, `❌ ${e.message}`)], ephemeral: true });
    }
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('kick').setDescription('Kick a member from the server')
    .addUserOption(o => o.setName('user').setDescription('User to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ User not in server.')], ephemeral: true });
    if (!member.kickable) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ I cannot kick this user.')], ephemeral: true });

    await user.send({ embeds: [modEmbed(0xfaa61a, `👢 You have been **kicked** from **${interaction.guild.name}**\n**Reason:** ${reason}`)] }).catch(() => {});
    await member.kick(reason);
    await logAction(client, interaction.guild.id, 'kick', { moderator: interaction.user, target: user, reason });
    interaction.reply({ embeds: [modEmbed(0xfaa61a, `👢 **${user.tag}** has been kicked.\n**Reason:** ${reason}`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('mute').setDescription('Timeout (mute) a member')
    .addUserOption(o => o.setName('user').setDescription('User to mute').setRequired(true))
    .addIntegerOption(o => o.setName('duration').setDescription('Duration in minutes').setRequired(true).setMinValue(1).setMaxValue(40320))
    .addStringOption(o => o.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const duration = interaction.options.getInteger('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ User not in server.')], ephemeral: true });
    if (!member.moderatable) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ I cannot mute this user.')], ephemeral: true });

    await member.timeout(duration * 60 * 1000, reason);
    await logAction(client, interaction.guild.id, 'mute', { moderator: interaction.user, target: user, reason, extra: { Duration: `${duration} minutes` } });
    interaction.reply({ embeds: [modEmbed(0xfee75c, `🔇 **${user.tag}** has been muted for **${duration} minute(s)**.\n**Reason:** ${reason}`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('unmute').setDescription('Remove timeout from a member')
    .addUserOption(o => o.setName('user').setDescription('User to unmute').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ User not in server.')], ephemeral: true });
    await member.timeout(null, reason);
    await logAction(client, interaction.guild.id, 'unmute', { moderator: interaction.user, target: user, reason });
    interaction.reply({ embeds: [modEmbed(0x00b0f4, `🔊 **${user.tag}** has been unmuted.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('warn').setDescription('Issue a warning to a member')
    .addUserOption(o => o.setName('user').setDescription('User to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    const count = client.db.addWarning(interaction.guild.id, user.id, reason, interaction.user.id, interaction.user.tag);
    const cfg = client.db.getGuildConfig(interaction.guild.id);
    const am = cfg.automod;

    await user.send({ embeds: [modEmbed(0xfee75c, `⚠️ You received a warning in **${interaction.guild.name}**\n**Reason:** ${reason}\nYou now have **${count}** warning(s).`)] }).catch(() => {});
    await logAction(client, interaction.guild.id, 'warn', { moderator: interaction.user, target: user, reason, extra: { 'Total Warnings': count } });

    // Auto-punish based on warning count
    if (am?.punishments) {
      const member = interaction.guild.members.cache.get(user.id);
      if (member) {
        const p = am.punishments;
        if (p.ban && count >= p.ban) {
          await member.ban({ reason: `Auto-ban: ${count} warnings` }).catch(() => {});
        } else if (p.kick && count >= p.kick) {
          await member.kick(`Auto-kick: ${count} warnings`).catch(() => {});
        } else if (p.mute && count >= p.mute) {
          await member.timeout(600000, `Auto-mute: ${count} warnings`).catch(() => {});
        }
      }
    }

    interaction.reply({ embeds: [modEmbed(0xfee75c, `⚠️ **${user.tag}** has been warned. They now have **${count}** warning(s).\n**Reason:** ${reason}`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('warnings').setDescription('View warnings for a user')
    .addUserOption(o => o.setName('user').setDescription('User to check').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const warns = client.db.getWarnings(interaction.guild.id, user.id);
    const embed = new EmbedBuilder().setColor(0xfee75c).setTitle(`⚠️ Warnings — ${user.tag}`).setThumbnail(user.displayAvatarURL())
      .setDescription(warns.length ? warns.map((w, i) => `**#${i+1}** \`${w.id}\` — ${w.reason}\n└ by <@${w.moderatorId}> • <t:${Math.floor(new Date(w.timestamp)/1000)}:R>`).join('\n\n') : '✅ No warnings on record.')
      .setFooter({ text: `${warns.length} warning(s) total` });
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('delwarn').setDescription('Delete a specific warning by ID')
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .addStringOption(o => o.setName('warnid').setDescription('Warning ID').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const warnId = interaction.options.getString('warnid');
    const removed = client.db.removeWarning(interaction.guild.id, user.id, warnId);
    interaction.reply({ embeds: [modEmbed(removed ? 0x57f287 : 0xed4245, removed ? `✅ Warning \`${warnId}\` removed from **${user.tag}**.` : '❌ Warning not found.')], ephemeral: !removed });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('clearwarnings').setDescription('Clear all warnings for a user')
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    client.db.clearWarnings(interaction.guild.id, user.id);
    await logAction(client, interaction.guild.id, 'clearwarnings', { moderator: interaction.user, target: user, reason: 'Warnings cleared' });
    interaction.reply({ embeds: [modEmbed(0x57f287, `✅ All warnings cleared for **${user.tag}**.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('purge').setDescription('Delete multiple messages at once')
    .addIntegerOption(o => o.setName('amount').setDescription('Number to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Only delete from this user'))
    .addStringOption(o => o.setName('filter').setDescription('Filter type').addChoices(
      { name: 'All', value: 'all' }, { name: 'Bots', value: 'bots' }, { name: 'Humans', value: 'humans' },
      { name: 'Contains link', value: 'links' }, { name: 'Contains image', value: 'images' }
    ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    const amount = interaction.options.getInteger('amount');
    const filterUser = interaction.options.getUser('user');
    const filter = interaction.options.getString('filter') || 'all';

    let messages = await interaction.channel.messages.fetch({ limit: 100 });

    if (filterUser) messages = messages.filter(m => m.author.id === filterUser.id);
    if (filter === 'bots') messages = messages.filter(m => m.author.bot);
    if (filter === 'humans') messages = messages.filter(m => !m.author.bot);
    if (filter === 'links') messages = messages.filter(m => /https?:\/\/\S+/.test(m.content));
    if (filter === 'images') messages = messages.filter(m => m.attachments.size > 0 || m.embeds.some(e => e.image));

    const toDelete = [...messages.values()].slice(0, amount);
    const deleted = await interaction.channel.bulkDelete(toDelete, true);

    await logAction(client, interaction.guild.id, 'purge', {
      moderator: interaction.user, reason: `Purged ${deleted.size} messages`,
      extra: { Channel: `#${interaction.channel.name}`, Count: deleted.size, Filter: filter },
    });

    interaction.editReply({ embeds: [modEmbed(0xeb459e, `🗑️ Deleted **${deleted.size}** message(s) from **#${interaction.channel.name}**.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('slowmode').setDescription('Set slowmode for a channel')
    .addIntegerOption(o => o.setName('seconds').setDescription('Seconds (0 to disable)').setRequired(true).setMinValue(0).setMaxValue(21600))
    .addChannelOption(o => o.setName('channel').setDescription('Channel (defaults to current)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction, client) {
    const seconds = interaction.options.getInteger('seconds');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    await channel.setRateLimitPerUser(seconds);
    await logAction(client, interaction.guild.id, 'slowmode', {
      moderator: interaction.user, reason: seconds === 0 ? 'Disabled' : `Set to ${seconds}s`,
      extra: { Channel: `#${channel.name}`, Slowmode: seconds === 0 ? 'Disabled' : `${seconds}s` },
    });
    interaction.reply({ embeds: [modEmbed(0x5865f2, seconds === 0 ? `⏱️ Slowmode disabled in <#${channel.id}>.` : `⏱️ Slowmode set to **${seconds}s** in <#${channel.id}>.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('lockdown').setDescription('Lock or unlock a channel')
    .addStringOption(o => o.setName('action').setDescription('Action').setRequired(true).addChoices({ name: 'Lock', value: 'lock' }, { name: 'Unlock', value: 'unlock' }))
    .addStringOption(o => o.setName('reason').setDescription('Reason'))
    .addChannelOption(o => o.setName('channel').setDescription('Channel (defaults to current)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  async execute(interaction, client) {
    const action = interaction.options.getString('action');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const isLock = action === 'lock';

    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, { SendMessages: isLock ? false : null }, { reason });
    await logAction(client, interaction.guild.id, isLock ? 'lockdown' : 'unlock', {
      moderator: interaction.user, reason, extra: { Channel: `#${channel.name}` },
    });
    interaction.reply({ embeds: [modEmbed(isLock ? 0xed4245 : 0x57f287, isLock ? `🔒 <#${channel.id}> locked. **Reason:** ${reason}` : `🔓 <#${channel.id}> unlocked.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('nick').setDescription("Change a member's nickname")
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .addStringOption(o => o.setName('nickname').setDescription('New nickname (leave blank to reset)'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageNicknames),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const nick = interaction.options.getString('nickname') || null;
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ User not in server.')], ephemeral: true });
    await member.setNickname(nick, `Changed by ${interaction.user.tag}`);
    await logAction(client, interaction.guild.id, 'nickname', {
      moderator: interaction.user, target: user, reason: nick ? `Changed to: ${nick}` : 'Reset',
    });
    interaction.reply({ embeds: [modEmbed(0x9b59b6, nick ? `✏️ Nickname set to **${nick}** for **${user.tag}**.` : `✏️ Nickname reset for **${user.tag}**.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('role').setDescription('Add or remove a role from a member')
    .addStringOption(o => o.setName('action').setDescription('Action').setRequired(true).addChoices({ name: 'Add', value: 'add' }, { name: 'Remove', value: 'remove' }))
    .addUserOption(o => o.setName('user').setDescription('User').setRequired(true))
    .addRoleOption(o => o.setName('role').setDescription('Role').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),
  async execute(interaction, client) {
    const action = interaction.options.getString('action');
    const user = interaction.options.getUser('user');
    const role = interaction.options.getRole('role');
    const member = interaction.guild.members.cache.get(user.id);
    if (!member) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ User not in server.')], ephemeral: true });
    if (role.position >= interaction.guild.members.me.roles.highest.position)
      return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ I cannot manage this role.')], ephemeral: true });
    if (action === 'add') await member.roles.add(role);
    else await member.roles.remove(role);
    await logAction(client, interaction.guild.id, 'role', {
      moderator: interaction.user, target: user, reason: `${action === 'add' ? 'Added' : 'Removed'} role: ${role.name}`,
    });
    interaction.reply({ embeds: [modEmbed(0x3498db, `👑 **${role.name}** ${action === 'add' ? 'added to' : 'removed from'} **${user.tag}**.`)] });
  },
},

{
  category: 'Moderation',
  data: new SlashCommandBuilder().setName('modlogs').setDescription('View moderation history for a user')
    .addUserOption(o => o.setName('user').setDescription('User to look up'))
    .addStringOption(o => o.setName('action').setDescription('Filter by action type').addChoices(
      { name: 'Ban', value: 'ban' }, { name: 'Kick', value: 'kick' }, { name: 'Mute', value: 'mute' },
      { name: 'Warn', value: 'warn' }, { name: 'All', value: '' }
    ))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user');
    const action = interaction.options.getString('action') || undefined;
    let logs = client.db.getLogs(interaction.guild.id, { action, limit: 15 });
    if (user) logs = logs.filter(l => l.target?.id === user.id);

    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`📋 Mod Logs${user ? ` — ${user.tag}` : ''}`)
      .setDescription(logs.length ? logs.map(l =>
        `**${l.action.toUpperCase()}** • ${l.target?.tag || 'N/A'} • ${l.reason}\n└ <@${l.moderator?.id || 'AutoMod'}> • <t:${Math.floor(new Date(l.timestamp)/1000)}:R>`
      ).join('\n\n') : 'No logs found.');
    interaction.reply({ embeds: [embed], ephemeral: true });
  },
},

{
  category: 'Utility',
  data: new SlashCommandBuilder().setName('userinfo').setDescription('Get detailed info about a user')
    .addUserOption(o => o.setName('user').setDescription('User (defaults to yourself)')),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user') || interaction.user;
    const member = interaction.guild.members.cache.get(user.id);
    const warns = client.db.getWarnings(interaction.guild.id, user.id);
    const xp = client.db.getXP(interaction.guild.id, user.id);

    const flags = user.flags?.toArray().map(f => f.replace(/_/g, ' ')).join(', ') || 'None';

    const embed = new EmbedBuilder().setColor(member?.displayColor || 0x5865f2)
      .setTitle(`👤 ${user.tag}`)
      .setThumbnail(user.displayAvatarURL({ size: 256 }))
      .addFields(
        { name: '🆔 User ID', value: `\`${user.id}\``, inline: true },
        { name: '⚠️ Warnings', value: warns.length.toString(), inline: true },
        { name: '✨ XP / Level', value: `${xp.xp} XP / Level ${xp.level}`, inline: true },
        { name: '📅 Account Created', value: `<t:${Math.floor(user.createdTimestamp/1000)}:R>`, inline: true },
        { name: '📥 Joined Server', value: member ? `<t:${Math.floor(member.joinedTimestamp/1000)}:R>` : 'Not in server', inline: true },
        { name: '🏷️ Roles', value: member ? (member.roles.cache.filter(r => r.id !== interaction.guild.id).map(r => `<@&${r.id}>`).join(' ') || 'None') : 'N/A' },
        { name: '🎖️ Badges', value: flags },
      )
      .setFooter({ text: member?.presence ? `Status: ${member.presence.status}` : 'Offline' });
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Utility',
  data: new SlashCommandBuilder().setName('serverinfo').setDescription('Get info about this server'),
  async execute(interaction, client) {
    const g = interaction.guild;
    const stats = client.db.getStats(g.id);

    const embed = new EmbedBuilder().setColor(0x5865f2)
      .setTitle(`🏠 ${g.name}`)
      .setThumbnail(g.iconURL({ size: 256 }))
      .addFields(
        { name: '🆔 Server ID', value: `\`${g.id}\``, inline: true },
        { name: '👑 Owner', value: `<@${g.ownerId}>`, inline: true },
        { name: '👥 Members', value: g.memberCount.toString(), inline: true },
        { name: '💬 Channels', value: g.channels.cache.size.toString(), inline: true },
        { name: '🎭 Roles', value: g.roles.cache.size.toString(), inline: true },
        { name: '😀 Emojis', value: g.emojis.cache.size.toString(), inline: true },
        { name: '📅 Created', value: `<t:${Math.floor(g.createdTimestamp/1000)}:R>`, inline: true },
        { name: '🛡️ Total Mod Actions', value: stats.total.toString(), inline: true },
        { name: '🔒 Verification', value: g.verificationLevel.toString(), inline: true },
      )
      .setFooter({ text: `Boost level: ${g.premiumTier}` });
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Utility',
  data: new SlashCommandBuilder().setName('avatar').setDescription("Get a user's avatar")
    .addUserOption(o => o.setName('user').setDescription('User (defaults to yourself)')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`🖼️ ${user.tag}'s Avatar`)
      .setImage(user.displayAvatarURL({ size: 512 }))
      .addFields({ name: 'Download', value: `[PNG](${user.displayAvatarURL({ size: 512, extension: 'png' })}) • [WebP](${user.displayAvatarURL({ size: 512 })})` });
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Fun',
  data: new SlashCommandBuilder().setName('rank').setDescription('View your XP rank in this server')
    .addUserOption(o => o.setName('user').setDescription('User (defaults to yourself)')),
  async execute(interaction, client) {
    const user = interaction.options.getUser('user') || interaction.user;
    const xp = client.db.getXP(interaction.guild.id, user.id);
    const lb = client.db.getLeaderboard(interaction.guild.id, 100);
    const rank = lb.findIndex(e => e.userId === user.id) + 1;
    const nextLevelXp = Math.pow((xp.level + 1) / 0.1, 2);

    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`📊 Rank — ${user.tag}`)
      .setThumbnail(user.displayAvatarURL())
      .addFields(
        { name: '🏆 Rank', value: rank > 0 ? `#${rank}` : 'Unranked', inline: true },
        { name: '✨ Level', value: xp.level.toString(), inline: true },
        { name: '💬 XP', value: `${xp.xp} / ${Math.round(nextLevelXp)}`, inline: true },
        { name: '📨 Messages', value: xp.messages.toString(), inline: true },
      );
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Fun',
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('View the XP leaderboard'),
  async execute(interaction, client) {
    const lb = client.db.getLeaderboard(interaction.guild.id, 10);
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`🏆 Leaderboard — ${interaction.guild.name}`)
      .setDescription(lb.length ? lb.map((e, i) => `**${i+1}.** <@${e.userId}> — Level **${e.level}** • ${e.xp} XP`).join('\n') : 'No data yet. Start chatting!');
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Fun',
  data: new SlashCommandBuilder().setName('poll').setDescription('Create a poll')
    .addStringOption(o => o.setName('question').setDescription('Poll question').setRequired(true))
    .addStringOption(o => o.setName('options').setDescription('Options separated by | (e.g. Yes | No | Maybe)').setRequired(true))
    .addIntegerOption(o => o.setName('duration').setDescription('Duration in minutes (0 = no limit)').setMinValue(0)),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const opts = interaction.options.getString('options').split('|').map(s => s.trim()).slice(0, 10);
    const duration = interaction.options.getInteger('duration') || 0;
    const emojis = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];

    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle(`📊 ${question}`)
      .setDescription(opts.map((o, i) => `${emojis[i]} ${o}`).join('\n'))
      .setFooter({ text: duration ? `Ends in ${duration} minute(s)` : 'No time limit' })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
    const msg = await interaction.fetchReply();
    for (let i = 0; i < opts.length; i++) await msg.react(emojis[i]);
  },
},

{
  category: 'Fun',
  data: new SlashCommandBuilder().setName('8ball').setDescription('Ask the magic 8-ball a question')
    .addStringOption(o => o.setName('question').setDescription('Your question').setRequired(true)),
  async execute(interaction) {
    const responses = [
      '✅ It is certain.', '✅ Without a doubt.', '✅ Yes, definitely.', '✅ You may rely on it.',
      '🤔 Reply hazy, try again.', '🤔 Ask again later.', '🤔 Better not tell you now.',
      '❌ Don\'t count on it.', '❌ My reply is no.', '❌ Very doubtful.',
    ];
    const q = interaction.options.getString('question');
    const resp = responses[Math.floor(Math.random() * responses.length)];
    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('🎱 Magic 8-Ball')
      .addFields({ name: '❓ Question', value: q }, { name: '💬 Answer', value: resp });
    interaction.reply({ embeds: [embed] });
  },
},

{
  category: 'Tickets',
  data: new SlashCommandBuilder().setName('ticket').setDescription('Open a support ticket')
    .addStringOption(o => o.setName('reason').setDescription('Brief reason for your ticket')),
  async execute(interaction, client) {
    const cfg = client.db.getGuildConfig(interaction.guild.id);
    if (!cfg.tickets.enabled) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ Tickets are not enabled on this server.')], ephemeral: true });

    const reason = interaction.options.getString('reason') || 'No reason provided';
    const category = interaction.guild.channels.cache.get(cfg.tickets.categoryId);

    const channel = await interaction.guild.channels.create({
      name: `ticket-${interaction.user.username}`,
      parent: category || null,
      permissionOverwrites: [
        { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
        { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
        ...(cfg.tickets.supportRoleId ? [{ id: cfg.tickets.supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }] : []),
      ],
    });

    client.db.setTicket(interaction.guild.id, channel.id, {
      userId: interaction.user.id, reason, channelId: channel.id, createdAt: new Date().toISOString(), status: 'open',
    });

    const embed = new EmbedBuilder().setColor(0x5865f2).setTitle('🎫 Support Ticket')
      .setDescription(cfg.tickets.openMessage || 'Staff will be with you shortly.')
      .addFields({ name: 'Reason', value: reason })
      .setFooter({ text: 'React with 🔒 to close this ticket.' });

    const msg = await channel.send({ content: `<@${interaction.user.id}>${cfg.tickets.supportRoleId ? ` <@&${cfg.tickets.supportRoleId}>` : ''}`, embeds: [embed] });
    await msg.react('🔒');

    interaction.reply({ embeds: [modEmbed(0x57f287, `✅ Ticket created: <#${channel.id}>`)], ephemeral: true });
  },
},

{
  category: 'Tickets',
  data: new SlashCommandBuilder().setName('closeticket').setDescription('Close this support ticket')
    .addStringOption(o => o.setName('reason').setDescription('Reason for closing')),
  async execute(interaction, client) {
    const ticket = client.db.getTicket(interaction.guild.id, interaction.channel.id);
    if (!ticket) return interaction.reply({ embeds: [modEmbed(0xed4245, '❌ This is not a ticket channel.')], ephemeral: true });

    const reason = interaction.options.getString('reason') || 'Closed by staff';
    await interaction.reply({ embeds: [modEmbed(0xfaa61a, `🔒 Ticket closing in 5 seconds...\n**Reason:** ${reason}`)] });
    client.db.closeTicket(interaction.guild.id, interaction.channel.id);
    setTimeout(() => interaction.channel.delete().catch(() => {}), 5000);
  },
},

];
