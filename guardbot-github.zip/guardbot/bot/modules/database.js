/**
 * Database module using JSON files for portability.
 * In production, swap for SQLite (better-sqlite3) or MongoDB.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

function loadTable(name) {
  const file = path.join(DATA_DIR, `${name}.json`);
  if (!fs.existsSync(file)) { fs.writeFileSync(file, '{}'); return {}; }
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return {}; }
}

function saveTable(name, data) {
  fs.writeFileSync(path.join(DATA_DIR, `${name}.json`), JSON.stringify(data, null, 2));
}

// In-memory cache
const cache = {};
const dirty = new Set();

function getTable(name) {
  if (!cache[name]) cache[name] = loadTable(name);
  return cache[name];
}

// Debounced saves
setInterval(() => {
  for (const name of dirty) { saveTable(name, cache[name]); }
  dirty.clear();
}, 2000);

const db = {
  // ── Guild config ──────────────────────────────────────────────────────────
  getGuildConfig(guildId) {
    const t = getTable('guild_configs');
    if (!t[guildId]) t[guildId] = db.defaultConfig();
    return t[guildId];
  },
  setGuildConfig(guildId, config) {
    const t = getTable('guild_configs');
    t[guildId] = config;
    dirty.add('guild_configs');
  },
  defaultConfig() {
    return {
      prefix: '!',
      logChannelId: null,
      modRoles: [],
      adminRoles: [],
      muteRoleId: null,
      joinLeave: { enabled: false, channelId: null, joinMsg: 'Welcome {user} to {server}!', leaveMsg: '{username} has left {server}.' },
      automod: {
        enabled: false,
        maxMentions: 5,
        maxEmojis: 15,
        antiSpam: { enabled: false, threshold: 5, window: 4000 },
        linkFilter: { enabled: false, whitelist: [] },
        bannedWords: [],
        capsFilter: { enabled: false, percent: 70 },
        inviteFilter: false,
        duplicateFilter: false,
        newAccountFilter: { enabled: false, ageDays: 7 },
        punishments: { warn: 1, mute: 3, kick: 5, ban: 7 },
      },
      leveling: { enabled: false, xpRate: 1, xpCooldown: 60, announceLevelUp: true, announceChannelId: null },
      starboard: { enabled: false, channelId: null, threshold: 3, emoji: '⭐' },
      verification: { enabled: false, roleId: null, channelId: null, message: 'React with ✅ to verify.' },
      antiRaid: { enabled: false, joinThreshold: 10, joinWindow: 10000, action: 'kick' },
      tickets: { enabled: false, categoryId: null, supportRoleId: null, openMessage: 'Support ticket opened! Staff will be with you shortly.' },
      reactionRoles: [],
      customCommands: [],
      ignoredChannels: [],
      ignoredRoles: [],
    };
  },

  // ── Warnings ──────────────────────────────────────────────────────────────
  getWarnings(guildId, userId) {
    const t = getTable('warnings');
    const key = `${guildId}:${userId}`;
    return t[key] || [];
  },
  addWarning(guildId, userId, reason, moderatorId, moderatorTag) {
    const t = getTable('warnings');
    const key = `${guildId}:${userId}`;
    if (!t[key]) t[key] = [];
    const w = { id: Date.now().toString(36), reason, moderatorId, moderatorTag, timestamp: new Date().toISOString() };
    t[key].push(w);
    dirty.add('warnings');
    return t[key].length;
  },
  removeWarning(guildId, userId, warnId) {
    const t = getTable('warnings');
    const key = `${guildId}:${userId}`;
    if (!t[key]) return false;
    const before = t[key].length;
    t[key] = t[key].filter(w => w.id !== warnId);
    dirty.add('warnings');
    return t[key].length < before;
  },
  clearWarnings(guildId, userId) {
    const t = getTable('warnings');
    delete t[`${guildId}:${userId}`];
    dirty.add('warnings');
  },

  // ── Mod logs ──────────────────────────────────────────────────────────────
  getLogs(guildId, { action, limit = 50 } = {}) {
    const t = getTable('modlogs');
    let logs = t[guildId] || [];
    if (action) logs = logs.filter(l => l.action === action);
    return logs.slice(0, parseInt(limit));
  },
  addLog(guildId, entry) {
    const t = getTable('modlogs');
    if (!t[guildId]) t[guildId] = [];
    t[guildId].unshift({ ...entry, id: Date.now().toString(36), timestamp: new Date().toISOString() });
    if (t[guildId].length > 1000) t[guildId] = t[guildId].slice(0, 1000);
    dirty.add('modlogs');
    return entry;
  },

  // ── Leveling ──────────────────────────────────────────────────────────────
  getXP(guildId, userId) {
    const t = getTable('levels');
    return t[`${guildId}:${userId}`] || { xp: 0, level: 0, messages: 0 };
  },
  addXP(guildId, userId, amount) {
    const t = getTable('levels');
    const key = `${guildId}:${userId}`;
    if (!t[key]) t[key] = { xp: 0, level: 0, messages: 0 };
    t[key].xp += amount;
    t[key].messages++;
    const newLevel = Math.floor(0.1 * Math.sqrt(t[key].xp));
    const leveled = newLevel > t[key].level;
    t[key].level = newLevel;
    dirty.add('levels');
    return { ...t[key], leveled };
  },
  getLeaderboard(guildId, limit = 10) {
    const t = getTable('levels');
    return Object.entries(t)
      .filter(([k]) => k.startsWith(guildId + ':'))
      .map(([k, v]) => ({ userId: k.split(':')[1], ...v }))
      .sort((a, b) => b.xp - a.xp)
      .slice(0, limit);
  },

  // ── Starboard ─────────────────────────────────────────────────────────────
  getStarboardEntry(guildId, messageId) {
    const t = getTable('starboard');
    return (t[guildId] || {})[messageId] || null;
  },
  setStarboardEntry(guildId, messageId, data) {
    const t = getTable('starboard');
    if (!t[guildId]) t[guildId] = {};
    t[guildId][messageId] = data;
    dirty.add('starboard');
  },

  // ── Tickets ───────────────────────────────────────────────────────────────
  getTicket(guildId, channelId) {
    const t = getTable('tickets');
    return (t[guildId] || {})[channelId] || null;
  },
  setTicket(guildId, channelId, data) {
    const t = getTable('tickets');
    if (!t[guildId]) t[guildId] = {};
    t[guildId][channelId] = data;
    dirty.add('tickets');
  },
  getTickets(guildId) {
    const t = getTable('tickets');
    return Object.values(t[guildId] || {});
  },
  closeTicket(guildId, channelId) {
    const t = getTable('tickets');
    if (t[guildId]) delete t[guildId][channelId];
    dirty.add('tickets');
  },

  // ── Reaction Roles ────────────────────────────────────────────────────────
  getReactionRole(guildId, messageId, emoji) {
    const t = getTable('reaction_roles');
    const key = `${guildId}:${messageId}:${emoji}`;
    return t[key] || null;
  },
  setReactionRole(guildId, messageId, emoji, roleId) {
    const t = getTable('reaction_roles');
    t[`${guildId}:${messageId}:${emoji}`] = { roleId, guildId, messageId, emoji };
    dirty.add('reaction_roles');
  },
  removeReactionRole(guildId, messageId, emoji) {
    const t = getTable('reaction_roles');
    delete t[`${guildId}:${messageId}:${emoji}`];
    dirty.add('reaction_roles');
  },
  getGuildReactionRoles(guildId) {
    const t = getTable('reaction_roles');
    return Object.values(t).filter(r => r.guildId === guildId);
  },

  // ── Mutes (persistent) ────────────────────────────────────────────────────
  setMute(guildId, userId, expiresAt) {
    const t = getTable('mutes');
    t[`${guildId}:${userId}`] = { expiresAt };
    dirty.add('mutes');
  },
  getMute(guildId, userId) {
    const t = getTable('mutes');
    return t[`${guildId}:${userId}`] || null;
  },
  removeMute(guildId, userId) {
    const t = getTable('mutes');
    delete t[`${guildId}:${userId}`];
    dirty.add('mutes');
  },

  // ── Spam tracking (in-memory only) ───────────────────────────────────────
  _spamMap: new Map(),
  _xpCooldown: new Map(),
  checkSpam(userId, threshold, window) {
    const now = Date.now();
    const times = (this._spamMap.get(userId) || []).filter(t => now - t < window);
    times.push(now);
    this._spamMap.set(userId, times);
    return times.length >= threshold;
  },
  checkXPCooldown(guildId, userId, cooldownSecs) {
    const key = `${guildId}:${userId}`;
    const last = this._xpCooldown.get(key) || 0;
    if (Date.now() - last < cooldownSecs * 1000) return false;
    this._xpCooldown.set(key, Date.now());
    return true;
  },

  // ── Stats ─────────────────────────────────────────────────────────────────
  getStats(guildId) {
    const logs = getTable('modlogs')[guildId] || [];
    const count = a => logs.filter(l => l.action === a).length;
    return {
      bans: count('ban'), kicks: count('kick'), mutes: count('mute'),
      warns: count('warn'), unbans: count('unban'), purges: count('purge'),
      automod: count('automod'), total: logs.length,
    };
  },
  getAllGuildIds() {
    return Object.keys(getTable('guild_configs'));
  },
};

module.exports = db;
