const express = require('express');
const cors = require('cors');
const session = require('express-session');
const axios = require('axios');

const app = express();
const PORT = process.env.API_PORT || 3001;

app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || 'guardbot-secret-change-in-production',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 86400000 },
}));

let _client = null;

// ── Auth helpers ──────────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session?.user) return next();
  res.status(401).json({ error: 'Unauthorized' });
}

function requireGuildAccess(req, res, next) {
  const { guildId } = req.params;
  const guild = _client?.guilds.cache.get(guildId);
  if (!guild) return res.status(404).json({ error: 'Guild not found' });
  req.guild = guild;
  next();
}

// ── OAuth2 ────────────────────────────────────────────────────────────────────
app.get('/auth/discord', (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.CLIENT_ID,
    redirect_uri: process.env.REDIRECT_URI || `http://localhost:${PORT}/auth/callback`,
    response_type: 'code',
    scope: 'identify guilds',
  });
  res.redirect(`https://discord.com/api/oauth2/authorize?${params}`);
});

app.get('/auth/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect('/?error=no_code');
  try {
    const tokenRes = await axios.post('https://discord.com/api/oauth2/token',
      new URLSearchParams({
        client_id: process.env.CLIENT_ID,
        client_secret: process.env.CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: process.env.REDIRECT_URI || `http://localhost:${PORT}/auth/callback`,
      }),
      { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
    );
    const { access_token, token_type } = tokenRes.data;
    const [userRes, guildsRes] = await Promise.all([
      axios.get('https://discord.com/api/users/@me', { headers: { Authorization: `${token_type} ${access_token}` } }),
      axios.get('https://discord.com/api/users/@me/guilds', { headers: { Authorization: `${token_type} ${access_token}` } }),
    ]);
    req.session.user = { ...userRes.data, guilds: guildsRes.data, accessToken: access_token };
    res.redirect('/dashboard');
  } catch (e) {
    console.error('OAuth error:', e.response?.data || e.message);
    res.redirect('/?error=oauth_failed');
  }
});

app.get('/auth/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

app.get('/auth/me', (req, res) => {
  if (!req.session?.user) return res.json({ loggedIn: false });
  const { id, username, discriminator, avatar, guilds } = req.session.user;
  res.json({ loggedIn: true, user: { id, username, discriminator, avatar }, guilds });
});

// ── Bot status ────────────────────────────────────────────────────────────────
app.get('/api/status', (req, res) => {
  const client = _client;
  res.json({
    online: client?.isReady() || false,
    user: client?.user ? { id: client.user.id, tag: client.user.tag, avatar: client.user.displayAvatarURL() } : null,
    guilds: client?.guilds.cache.size || 0,
    uptime: client?.uptime || 0,
    ping: client?.ws.ping || 0,
    users: client?.guilds.cache.reduce((a, g) => a + g.memberCount, 0) || 0,
  });
});

// ── Guild list for dashboard ──────────────────────────────────────────────────
app.get('/api/guilds', requireAuth, (req, res) => {
  const userGuilds = req.session.user.guilds || [];
  const botGuilds = _client?.guilds.cache;

  const mutual = userGuilds
    .filter(g => (parseInt(g.permissions) & 0x20) === 0x20) // MANAGE_GUILD
    .map(g => ({
      ...g,
      botPresent: botGuilds?.has(g.id) || false,
      icon: g.icon ? `https://cdn.discordapp.com/icons/${g.id}/${g.icon}.png` : null,
    }));

  res.json(mutual);
});

// ── Per-guild API ─────────────────────────────────────────────────────────────
const guildRouter = express.Router({ mergeParams: true });
app.use('/api/guild/:guildId', requireAuth, requireGuildAccess, guildRouter);

guildRouter.get('/info', (req, res) => {
  const g = req.guild;
  const cfg = _client.db.getGuildConfig(g.id);
  const stats = _client.db.getStats(g.id);
  res.json({
    id: g.id, name: g.name, icon: g.iconURL(), memberCount: g.memberCount,
    channels: g.channels.cache.filter(c => c.type === 0).map(c => ({ id: c.id, name: c.name })),
    roles: g.roles.cache.filter(r => r.name !== '@everyone').map(r => ({ id: r.id, name: r.name, color: r.hexColor })),
    categories: g.channels.cache.filter(c => c.type === 4).map(c => ({ id: c.id, name: c.name })),
    config: cfg, stats,
  });
});

guildRouter.post('/config', (req, res) => {
  const cfg = _client.db.getGuildConfig(req.guild.id);
  const updated = { ...cfg, ...req.body };
  _client.db.setGuildConfig(req.guild.id, updated);
  res.json({ success: true, config: updated });
});

guildRouter.get('/logs', (req, res) => {
  const { action, limit } = req.query;
  res.json(_client.db.getLogs(req.guild.id, { action, limit }));
});

guildRouter.get('/warnings/:userId', (req, res) => {
  res.json(_client.db.getWarnings(req.guild.id, req.params.userId));
});

guildRouter.delete('/warnings/:userId', (req, res) => {
  _client.db.clearWarnings(req.guild.id, req.params.userId);
  res.json({ success: true });
});

guildRouter.get('/leaderboard', (req, res) => {
  res.json(_client.db.getLeaderboard(req.guild.id, 20));
});

guildRouter.get('/stats', (req, res) => {
  res.json(_client.db.getStats(req.guild.id));
});

guildRouter.get('/tickets', (req, res) => {
  res.json(_client.db.getTickets(req.guild.id));
});

guildRouter.get('/reaction-roles', (req, res) => {
  res.json(_client.db.getGuildReactionRoles(req.guild.id));
});

// ── Public stats endpoint ─────────────────────────────────────────────────────
app.get('/api/public/stats', (req, res) => {
  res.json({
    guilds: _client?.guilds.cache.size || 0,
    users: _client?.guilds.cache.reduce((a, g) => a + g.memberCount, 0) || 0,
    commands: _client?.commands.size || 0,
    uptime: _client?.uptime || 0,
  });
});

// ── Commands list ─────────────────────────────────────────────────────────────
app.get('/api/commands', (req, res) => {
  if (!_client) return res.json([]);
  res.json([..._client.commands.values()].map(c => ({
    name: c.data.name,
    description: c.data.description,
    category: c.category || 'General',
    options: c.data.options?.map(o => ({ name: o.name, description: o.description, required: o.required, type: o.type })) || [],
  })));
});

module.exports = {
  start(client) {
    _client = client;
    app.listen(PORT, () => console.log(`🌐 Dashboard API running on :${PORT}`));
  },
  app,
};
