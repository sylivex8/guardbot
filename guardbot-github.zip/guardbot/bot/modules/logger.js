const { EmbedBuilder } = require('discord.js');

const ACTION_COLORS = {
  ban: 0xed4245,
  unban: 0x57f287,
  kick: 0xfaa61a,
  mute: 0xfee75c,
  unmute: 0x00b0f4,
  warn: 0xfee75c,
  clearwarnings: 0x57f287,
  purge: 0xeb459e,
  lockdown: 0xed4245,
  unlock: 0x57f287,
  slowmode: 0x5865f2,
  automod: 0x5865f2,
  nickname: 0x9b59b6,
  role: 0x3498db,
};

const ACTION_ICONS = {
  ban: '🔨', unban: '✅', kick: '👢', mute: '🔇', unmute: '🔊',
  warn: '⚠️', clearwarnings: '🗑️', purge: '🗑️', lockdown: '🔒',
  unlock: '🔓', slowmode: '⏱️', automod: '🛡️', nickname: '✏️', role: '👑',
};

async function logAction(client, guildId, action, { moderator, target, reason, extra = {} } = {}) {
  const db = client.db;
  const cfg = db.getGuildConfig(guildId);

  // Save to DB
  const entry = db.addLog(guildId, {
    action,
    moderator: moderator ? { id: moderator.id, tag: moderator.tag || moderator.username } : null,
    target: target ? { id: target.id, tag: target.tag || target.username || target.id } : null,
    reason: reason || 'No reason provided',
    extra,
  });

  // Send embed to log channel
  if (cfg.logChannelId) {
    const channel = client.channels.cache.get(cfg.logChannelId);
    if (channel) {
      const embed = new EmbedBuilder()
        .setColor(ACTION_COLORS[action] || 0x5865f2)
        .setTitle(`${ACTION_ICONS[action] || '📋'} ${action.toUpperCase()}`)
        .setTimestamp()
        .setFooter({ text: `Case ID: ${entry.id}` });

      if (target) embed.addFields({ name: 'Target', value: `<@${target.id}> \`${target.tag || target.id}\``, inline: true });
      if (moderator) embed.addFields({ name: 'Moderator', value: `<@${moderator.id}>`, inline: true });
      embed.addFields({ name: 'Reason', value: reason || 'No reason provided' });

      for (const [k, v] of Object.entries(extra)) {
        embed.addFields({ name: k, value: String(v), inline: true });
      }

      channel.send({ embeds: [embed] }).catch(() => {});
    }
  }

  return entry;
}

module.exports = { logAction, ACTION_COLORS, ACTION_ICONS };
